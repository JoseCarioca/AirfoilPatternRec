function y=stdpat(x);
% STDPAT   - Desv. standard de un conjunto de patrones
%
%    y = stdpat(x);
  
%	Copyright (c) Pedro L. Galindo (1998)

y = std(x')';
