function y = covpat(x)
% COVPAT   - Matriz de covarianza de un conjunto de patrones
%
%       y = covpat(x)
%

%	Copyright (c) Pedro L. Galindo (1998)

y=cov(x');
